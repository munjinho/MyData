<?php
    session_start();
    if(!isset($_SESSION['is_login'])){
        header('Location: ./login_file2.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>main</title>
    </head>
    <body>
        <?php
            //이미지 로그아웃 버튼 
            //$btm=$_POST['butm'];
            
                    echo "(".$_SESSION['name'].")님 ^__^ 환영합니다. <br/>";
                    
 //logout.php ->           
        ?>
        <a href="./logout.php">로그아웃</a>

    </body>
</html>
