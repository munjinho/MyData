<?php
        
   include("dbi.php");

    $id="mjh9083";

    $distinct="select distinct * from WebSign_up";
    $select="select * from WebSign_up where id='$id'";// 아이디값이 들어가고
    $query3=mysql_query($select);


    $row=mysql_fetch_array($query3);
    echo "name: ".$row[0]."<br>"; // 배열 0: 첫번째 있는 컬럼의 데이터를 불러옴니다..
    //===================
    echo "phone: ".$row[1]."<br>"; // 배열 1: 두번째 있는 컬럼의 데이터를 불러옴니다.
    //===================
    echo "sex: ".$row[2]."<br>"; // 배열 2: 세번째 있는 컬럼의 데이터를 불러옴니다.
    //===================
    echo "birth".$row[3]."<br>"; // 배열 3: 네번째 있는 컬럼의 데이터를 불러옴니다.

   // while($row=mysql_fetch_array($query3)){// 반복된다.
       
        //echo $row['id']."<br>";
    //}
           
?>

