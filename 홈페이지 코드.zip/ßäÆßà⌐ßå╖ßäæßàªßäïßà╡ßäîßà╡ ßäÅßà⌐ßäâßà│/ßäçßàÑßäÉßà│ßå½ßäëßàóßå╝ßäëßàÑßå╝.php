<html>
    <head>
    <title>버튼생성연습</title>
    </head>

    <body>
     <form method="post" action="버튼생성2.php">
     입력 값: <input type="text" name="in"><br>
         <input type="submit" name="확인" value="확인">
         <input type="reset" name="취소" value="취소"><br>
     </form>
    </body>
</html>