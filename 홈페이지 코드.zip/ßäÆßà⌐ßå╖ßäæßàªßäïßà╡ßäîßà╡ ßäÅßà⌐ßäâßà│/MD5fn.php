<?php
$string="jinho";
echo md5($string); //echo 앞에? 사용하면 md5가 실행된다.
?>

