<?php
print "test1\"\"test2";
?>

