<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>test</title>
    </head>
    <body>
        <?php
            setcookie('php','쿠키초:'); 
            $time=setcookie('php2','testnum1',time()+120,'/','mjh9082.dothome.co.kr');
            //쿠키 이름, 쿠키 값, 만료 시간, 경로, 도메인, 보안 
            
            if($time){
            echo "쿠키 생성";
            }
            else{
            echo "쿠키 생성실패";
            }
        ?>
    </body>
</html>
