<?php
    include("dbi.php");
    $id=$_POST['id'];

    $distinct="select distinct * from WebSign_up";// 중복아이디 삭제
    $select="select * from WebSign_up";
    //==========================================
    $query2=mysql_query($distinct);// 중복확인
    $query3=mysql_query($select);
    $row=mysql_fetch_array($query2);
     while($row=FALSE){  // DB안에 있는 데이터만큼 반복/또는 보여주려고 한다.
       //echo var_dump($row);
      // $row=mysql_fetch_array($query2);
       if($row){
           echo"1.test";
           if($query3)
           echo"불가능한 ID.!<br>";          
       }
       if($row!=$query3){
           echo"가입가능<br>";
       }
       echo"output";
     }
?>

