<html>
    <body>
    <form method="post" action="receive.php">
        <input type="text" name="a">
        <br>
        <input type="submit" value="확인">
    </form>
    </body>
</html>
