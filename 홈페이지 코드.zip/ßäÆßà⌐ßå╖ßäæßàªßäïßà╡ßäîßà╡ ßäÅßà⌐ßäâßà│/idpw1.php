<?php   
  $true=TRUE;
  $false=FALSE;
  
   if($true){//    if문 (단일)
        echo "단일";
        if($true){// if문 (다중)
            echo "다중";
        }
   }
   elseif($false){//  
       echo "단일2";
       if($true){
           echo "다중2";
       }
   }
   else{// 
       echo "이외";
   }

?>