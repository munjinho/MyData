<?php
    
    include("dbi.php");
     //=================================================
     $name=$_POST['name'];
     $phone=$_POST['phone'];
     $sex=$_POST['sex'];
     $birth=$_POST['birth'];
     //$id=$_POST['id'];
     $check=$_POST['check'];
     $pws=$_POST['pws'];
     $ok=$_POST['ok'];
     //=================================================
    
    
     //========================쿼리 라인
     $insert="insert into WebSign_up (name,phone,sex,birth,id,pws,ip) values('$name','$phone','$sex','$birth','$id','$pws','$_SERVER[REMOTE_ADDR]')"; //데이터 추가
    
     //============================================
     $query=mysql_query("set names utf8");
     //============================================
     //fetch_array로 반복문써서 쿼리 테스트
    
     //$num=mysql_num_rows($query3);
    // 아이디 (중복 확인) /이름, 아이디, 남/녀 입력check!!
    //=================================
    
    
     if($ok){
         echo"데이터저장";
        $query1=mysql_query($insert);//데이터 입력
      }
     elseif($check){
         echo"중복데이터";
          include("Webid_check.php");
      }
      
     mysql_close($db);
    
?>

