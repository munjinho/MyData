

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <?php 
            include('dbi.php');
            session_start();
            $id=$_POST['id'];
            $pws=$_POST['pw'];
            $login=$_POST['login'];
            $select="select * from WebSign_up where id='$id' and pws='$pws'";
            $query=mysql_query($select);
            //
                if($login){
                    id_check($id,$pws,$query,$select);
                }
		if(!$id){echo"아이디를 입력하세요<br>";}
		if(!$pws){echo"패스워드를 입력사세요<br>";}
        else{echo"가입 확인되지 않습니다."; die();}    

          
         function id_check($id,$pws,$query,$select){
            // echo"INPUT<br>";
             while($row=mysql_fetch_array($query)!=FALSE){ // select 같고
                    echo"통과1<br>";
                 if(!empty($id)&&!empty($pws)){
                    echo"통과2<br>";
                    if($query['id']!==$id&&$row['pws']!==$pws){// 비교
                        echo "통과3<br>";
                       
                        //===========
                    $_SESSION['is_login']=TRUE;
                    $_SESSION['name']=$id;
                    header('Location: ./session.php');// 여기 세션으로 수정
                    die();
                   }
                   else{
                       echo "로그인 실패"; 
                       die();
                   }
                   die();
                }
             }
            
           // echo"OUTPUT";
         }

            
            mysql_close($db);
        ?>
    </body>
</html>
     
