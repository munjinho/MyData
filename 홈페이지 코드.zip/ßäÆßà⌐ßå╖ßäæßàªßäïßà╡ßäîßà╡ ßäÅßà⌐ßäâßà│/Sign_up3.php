

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>중복체크</title>
    </head>
    <body>
        <?php
            echo "$id: 사용가능 합니다.";
        ?>

            <a href="./index2.html"><input type="submit" name="ckid" value="확인"></a>
        
        

    </body>
</html>
