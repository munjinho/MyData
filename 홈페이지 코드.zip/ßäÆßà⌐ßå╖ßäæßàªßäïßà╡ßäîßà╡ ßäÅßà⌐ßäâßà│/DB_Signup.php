<?php
  $id=$_POST['id'];
    //$id=20123008;
   

    $db=mysql_connect("localhost","mjh9083","answlsgh93","mjh9083"); //DB 접속

    mysql_select_db("mjh9083",$db);// 테이블 선택
    /////////////////////////////////////////////////

    mysql_query("set names utf8");// 한글 깨짐방지
    $sql="select id from Sign_up where id='$id'";// 회원가입 테이블에 아이디있는지 확인하는 SQL문
   
    $query=mysql_query($sql);
    $qarray=mysql_fetch_array($query);

    if($qarray['id']){
        echo"1";
    }
    else{
        echo"0";
    }
//중복기능
?>

