<?php

         //     MYSQL 접속 //
    
        $hostname = "localhost";
        $mysql_id = "mjh9083";
        $mysql_pw = "answlsgh93";
        $mysql_database = "mjh9083";
    //////////////////////////////////////
        //$id=$_POST['id'];
        //$pw=$_POST['pw'];
    
        $id=20123008;
        $pw=9083;
        ////////////////////////////////////////////////////////
    
    
    
        $db = mysql_connect($hostname,$mysql_id,$mysql_pw,$mysql_database);// DB접속
    
    
    
        mysql_select_db($mysql_database, $db);// DB선택
        mysql_query("set names utf8"); // 한글 깨짐 방지
    
    
    
    
        $sql="select idx,id,pw  from Sign_up where id='$id' and pw='$pw'";// SQL문
        $query=mysql_query($sql);
        //echo $sql;
        $qarray=mysql_fetch_array($query);
        //echo $qarray['idx'];
        
    
        if($qarray['id']==$id){
    
              if($qarray['pw']==$pw){
                //echo"1";
                    echo $qarray['idx'];//  id랑 pw랑 같을때 (인덱스 값을 출력 (예정))
              }
       } 
       else{
             echo "0";
             //echo mysql_insert_id();
       }
    
    /// login.php(로그안) 이후 newstudent.php (회원가입 수정)
    
    
    
        //mysql_close($db)
    
    
    
    
?>

