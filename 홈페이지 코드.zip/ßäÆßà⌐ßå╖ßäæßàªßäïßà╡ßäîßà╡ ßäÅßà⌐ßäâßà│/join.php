<?php
$a="hello";
$b="SQL";
print $a.$b;
?>

