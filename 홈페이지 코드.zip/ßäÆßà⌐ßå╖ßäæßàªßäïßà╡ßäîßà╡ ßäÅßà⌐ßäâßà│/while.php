<?php
    $a=1;
    do{
        chop("{$a}<br>");
        $a++;
    }while($a<=10);
?>

<?php
    do{
    실행문;
    }while(조건);
?>
