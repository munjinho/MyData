<?php
     $hostname = "localhost";
     $mysql_id = "mjh9083";
     $mysql_pw = "answlsgh93";
     $mysql_database = "mjh9083";
    
     $id=20123008;//$_POST['id'];
     $answer="서울";//$_POST['answer'];
     $question=1;//$_POST['question'];   
  
     $db = mysql_connect($hostname, $mysql_id, $mysql_pw, $mysql_database);
     // DB접속
         
     mysql_select_db($mysql_database, $db) or die("die");// DB선택
   
     $sql="select * from Sign_up where id='$id' and pw='$pw' and question='$question'and answer='$answer'";
    
     echo($sql);
     $query=mysql_query($sql);
     $qarray=mysql_fetch_array($query) or die("die3");
    
     

     if(!$qarray['id']==$id){ // 학번이 같고 
        echo "test1";
        if(!$qarray['question']==$question){ //  질문 DB에 데이터가 똑같이 입력하면 통과
        echo "test2";
            if(!$qarray['answer']==$answer){ //  DB에 있는 답변 데이터랑 똑같으면 비밀번호 출력
                echo "test3";
                echo $qarray['pw'];
            }
        }           
     }

    
   else{
       echo "0"; 
   }
    
    
    
    
    
    
    
     mysql_close($db) 
       //echo mysql_insert_id();
    
     
?>

