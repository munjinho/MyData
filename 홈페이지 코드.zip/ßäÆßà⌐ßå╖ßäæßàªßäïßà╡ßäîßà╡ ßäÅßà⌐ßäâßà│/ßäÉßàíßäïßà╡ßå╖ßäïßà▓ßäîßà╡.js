<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
         <script>
            password = prompt("임시 비밀번호");
            if (password == 9082) {
                document.write("준비중..");
            }
            else
                document.write("접.근.금.지");
        </script>
    </body>
</html>
