<?php

  $hostname = "localhost";
        $mysql_id = "mjh9083";
        $mysql_pw = "answlsgh93";
        $mysql_database = "mjh9083";
   
        //$id=$_POST['id'];
        $pw=$_POST['pw'];
        //$answer=$_POST['answer'];
        //$id=20123008;
        //$pw=9083;
        //$answer='울산';
    
    
    
       $db = mysql_connect($hostname,$mysql_id,$mysql_pw,$mysql_database);// DB접속
  
        mysql_select_db($mysql_database, $db);// DB선택
 
        $sql="select pw  from Sign_up where pw='$pw'";// SQL문
        $query=mysql_query($sql);
        $qarray=mysql_fetch_array($query);
           
      
          if($qarray['pw']=$pw){//  id랑 pw랑 같을때 (인덱스 값을 출력 (예정))          
                echo $qarray['pw'];
          }
       
       else{
             echo "lost";
             //echo mysql_insert_id();
       }
 
        mysql_close($db)

?>

