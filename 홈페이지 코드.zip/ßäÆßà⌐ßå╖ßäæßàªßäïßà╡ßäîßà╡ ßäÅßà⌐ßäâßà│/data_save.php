<?php
   
   echo $_SERVER['SERVER_NAME']."<br>";
   echo $_SERVER['SERVER_PORT']."<br>";
   echo $_SERVER['HTTP_HOST']."<br>";
   echo $_SERVER['SERVER_PROTOCOL']."<br>";
?>

