<?php
   $num=$_POST["num"];
   $com=ceil($num/100);
   
   switch($num){
       case 1:
            $num =round($num*1.15);
            echo("당신의 내년 급여는 15% 인상된{$num}만원입니다.");
            break;
        case 2:
            $num=round($num*1.1);
            break;
        case 3:
            $num=round($num*1.05);
            break;
        case 4:
            $num=round($num*1.02);
            break;
        default :
            echo("당신의 내년 급여는 올해와 같은{$num}입니다.");
   }
    
    
?>