


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>

        <?php
                $id=$_POST['id'];  // 호출 로그인id
                $pws=$_POST['pws']; //호출 로그인pws
                //=======================
                //$check=$_GET['LOGIN'];  //HTML 하고 (연동확인)
                $login=$_POST['login'];  //login 버튼 눌렀을때..작동확인
            $select="select * from WebSign_up where id='$id' and pws='$pws'";  // 
            //$query=mysql_query($select);
            
            
            
                  //======================================
                   include("dbi.php");///DB 연결           
                  //==========================================
                                mysql_query("set names utf8");
                  //============================================
                               
                 
            if($select){
                echo $select;
                if($_SERVER['PHP_AUTH_USER']==$id){// 아이디가 다른데 로그인이 되는지 확인 세션으로 넘어간다.
                    
                }
            }
            
           
                              // 로그인 확인
            
                               echo"pass!";
                //}// 안되면 삭제
            
                   // while($array=mysql_fetch_array($query)!=FALSE){// 거짓->out
                           //로그인 유지  
            
            
            
                    //}
            
            
            
                  //=============================================
            
            
            
            
            
            
            
            
        ?>
    </body>
</html>
