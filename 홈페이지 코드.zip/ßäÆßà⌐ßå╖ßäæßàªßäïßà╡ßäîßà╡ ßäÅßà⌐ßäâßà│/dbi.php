<?php
    
    $hostname="localhost";
    $mysql_id="mjh9083";
    $mysql_pw="answlsgh93";
    $mysql_databases="mjh9083";
    
           $db=mysql_connect($hostname,$mysql_id,$mysql_pw);//URL,myadmin_id,myadmin_pw
    
          mysql_select_db($mysql_databases,$db);//데이터베이스,DB명


?>


