<?php
 /////////////////////////////////   
 $blg_title=$_POST['blg_title'];//  제목
 $blg_contents=$_POST['blg_contents'];// 내용
 //////////////////////////////////

 $hostname="localhost";
 $mysql_id="mjh9083";
 $mysql_pw="answlsgh93";
 $mysql_database="mjh9083";

 $db=mysql_connect($hostname,$mysql_id,$mysql_pw,$mysql_database);

 mysql_select_db($mysql_database,$db);

 mysql_query("set names utf8"); // 깨짐현상 방지
 $sql="insert into blog (blg_title,blg_contents) values($blg_title,$blg_contents)";
 $query=mysql_query($sql);
 echo "$sql";
?>

