<?php
$hostname = "localhost";
$mysql_id = "mjh9083";
$mysql_pw = "answlsgh93";
$mysql_database = "mjh9083";



$db = mysql_connect($hostname, "mjh9083", "answlsgh93");

echo "연결성공";

mysql_select_db("Sign_up", $db) ;// 몬지 모름
print "가입_날짜".date("Y")."년".date("m")."월".date("j")."일";// 기록 생성

mysql_close($db);// mysql_connect()함수 종료

?>
