<html>
    <body>
        <hr>
        <?php
            $num=$_POST["in"];
            echo ("입력 값은($num)입니다. ");    
        ?>
        <hr>
    </body>
</html>