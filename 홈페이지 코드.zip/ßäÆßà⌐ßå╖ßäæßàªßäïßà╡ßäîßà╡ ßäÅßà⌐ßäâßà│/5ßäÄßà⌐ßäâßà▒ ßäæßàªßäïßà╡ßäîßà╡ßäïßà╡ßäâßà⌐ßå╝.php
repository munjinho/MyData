
<?php
    print "<META http-equiv='refresh' content='5; URL=http://mjh9082.blog.me/'>";
    print" 5초 후에 프리렉 화면으로 이용합니다.";
?>
  