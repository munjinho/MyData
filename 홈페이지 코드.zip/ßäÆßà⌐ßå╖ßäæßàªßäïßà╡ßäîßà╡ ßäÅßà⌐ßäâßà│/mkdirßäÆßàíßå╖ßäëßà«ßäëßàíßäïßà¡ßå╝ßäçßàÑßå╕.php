<?php
    $dir='testfile_0_1';
    mkdir($dir);//rmdir 도 가능
?>

