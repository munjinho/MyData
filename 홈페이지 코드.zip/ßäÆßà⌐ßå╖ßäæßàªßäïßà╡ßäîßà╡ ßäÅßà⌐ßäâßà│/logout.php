

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <?php
          ini_set("display_errors","1");
          session_start();
          session_destroy();
          header('Location: ./index.html');  
        ?>
    </body>
</html>
