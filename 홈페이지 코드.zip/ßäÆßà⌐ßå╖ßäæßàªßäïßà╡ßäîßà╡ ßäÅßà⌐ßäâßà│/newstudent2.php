<?php
    
         //     MYSQL 접속 //
    
        $hostname = "localhost";
        $mysql_id = "mjh9083";
        $mysql_pw = "answlsgh93";
        $mysql_database = "mjh9083";
    //////////////////////////////////////
        //$id=$_POST['id'];
        //$pw=$_POST['pw'];
        //$name=$_POST['name'];
        //$sex=$_POST['sex'];
        //$phone=$_POST['phone'];
        //$birth=$_POST['birth'];
        //$question=$_POST['question'];
        //$answer=$_POST['answer'];
        $id=20123008;
        $pw=9083;
        $name="진호";
        $sex="남자";
        $phone=01031999082;
        $birth=199389;
        $question=0;
        $answer="서울";
        ////////////////////////////////////////////////////////
        $true=TRUE;
        $false=FALSE;
    
    
        $db = mysql_connect($hostname,$mysql_id,$mysql_pw,$mysql_database);// DB접속
    
        mysql_select_db($mysql_database, $db);// DB선택
        mysql_query("set names utf8"); // 한글 깨짐 방지
    
        //$sql="insert into Sign_up(id,pw,name,sex,phone,birth,question,answer) values ('$id','$pw','$name','$sex','$phone','$birth','$question','$answer');";
        $signin=mysql_query("insert into Sign_up(id,pw,name,sex,phone,birth,question,answer) values ('$id','$pw','$name','$sex','$phone','$birth','$question','$answer')");//  회원가입할때 사용하는 쿼리문(SQL문)
        //$qarray2=mysql_fetch_array($signin);
        $sql="select distinct * from Sign_up";
        $query=mysql_query($sql);
        
        if($signin){   // post에 입력한거랑 mysql_fetch_array에 
            //if(){
              //  if($name){
                    echo"0";
                //}
            //}
            die();
        }
        if($sql) {
            echo"1";
            die();
        }
        mysql_close($db)
    
?>
