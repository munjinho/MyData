<?php
    
    include("dbi.php");
     //=================================================
     $Nikname=$_POST['Nikname'];
     $name=$_POST['name'];
     $phone=$_POST['phone'];
     $sex=$_POST['sex'];
     $birth=$_POST['birth'];
     $id=$_POST['id'];
     $check=$_POST['check'];
     $pws=$_POST['pws'];//md5($_POST['pws']);
     $ok=$_POST['ok'];
     $idck=$_POST['ckid'];
     $key_pw=rand(1000,10000);
    
     //=================================================
    
    
     //========================쿼리 라인
     $insert="insert into WebSign_up (name,phone,sex,birth,id,pws,ip,key_pw) values('$name','$phone','$sex','$birth','$id','$pws','$_SERVER[REMOTE_ADDR]','$key_pw')"; //데이터 추가// 비번찾을때 필요한 랜덤 숫자 함수찾기
    
     //============================================
     $query=mysql_query("set names utf8");
     //============================================
     //fetch_array로 반복문써서 쿼리 테스트
    $distinct="select distinct * from WebSign_up where id='$id'";// 중복아이디 삭제
    $select="select idxs,id from WebSign_up where id='$id'";  // id 하나씩 불러오기
    //==========================================
     //$num=mysql_num_rows($query3);
    // 아이디 (중복 확인) /이름, 아이디, 남/녀 입력check!!
    //=================================
    
     $query2=mysql_query($distinct);// 중복확인
     $query3=mysql_query($select);
      if(!$id){
          echo"<script language=javascript>
          alert('ID를 입력하세요'); 
          location.href='index2.html'
          </script>";
    
          exit();
      }
      if($ok){
    
        $query1=mysql_query($insert);//데이터 입력
         echo"<script language=javascript>
          alert('ID:($id)가입완료! ^__^'); 
          location.href='index.html'
          </script>";
     // 추가수정 뒤로가기!!!
      }
      if($check){
         //echo"ID:";
            idcheck($query2,$query3,$id);
      }
    
     
      function idcheck($query2,$query3,$id){// 인자=select, distinct
      //echo"idcheck Fn_in<br>";
          while($row=mysql_fetch_array($query2)!=FALSE){                                                                        
              if($row==$query2){// DB를 전부 중복체크 해보고 있을경우
              
                  //if($id==$query2){
    
                     echo "<script language=javascript>
          alert('ID:($id)중복체크!'); 
            location.href='index2.html'
          </script>";
                  die();
              }
           
    
          }
            if($row['id']==FALSE||$id!=$query3){// DB에 id컬럼이 없을경우 
    
            // echo"$id: 사용이 가능합니다.";
               echo "<script language=javascript>
          alert('ID:($id)사용가능!'); 
            location.href='index2.html'
          </script>";
    
                  //가입가능
                   
             }
    
    
      }   
    
    
    
     mysql_close($db);
    
?>
