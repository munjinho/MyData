<?php
 $id=$_POST['id'];
 $id=$_POST['pw'];

 print"테스트";
 
?>

