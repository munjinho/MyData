
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <form action="테스트파일.php" method="post">
            <p>테스트_입력</p>
            <input type="text" name="id" value="">
            <input type="submit" value="중복확인">
        </form>
        <?php
                    $id=$_POST['id'];
            
                      $db=mysql_connect("localhost","mjh9083","answlsgh93","mjh9083"); //DB 접속
                      mysql_select_db("mjh9083",$db);// 테이블 선택
            
            
                      mysql_query("set names utf8");// 한글 깨짐방지
                      $sql="select id from WebSign_up where id='$id'";// 회원가입 테이블에 아이디있는지 확인하는 SQL문
                      $query=mysql_query($sql);
                    $qarray=mysql_fetch_array($query);
            
                     $distinct="select distinct * from WebSign_up";// 중복아이디 삭제
            $select="select * from WebSign_up";
            
            $query2=mysql_query($distinct);// 중복확인
            $query3=mysql_query($select);
            
             while($row=mysql_fetch_array($query2)){  // 반복된다.
               //echo var_dump($row);
               if($row){
                   if($query2==$id)
                   echo"아이디 중복";
               }
               else{
                   echo"가입가능";
               }
               echo"output<br>";
             }
            
        ?>

    </body>
</html>




