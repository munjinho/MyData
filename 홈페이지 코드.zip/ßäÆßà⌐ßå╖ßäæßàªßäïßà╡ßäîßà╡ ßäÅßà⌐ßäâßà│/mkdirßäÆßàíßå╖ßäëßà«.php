

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>

        <input type="button" name="check" value="메세지!">
        <?php
           if(mkdir("C:\Users\Administrator\Desktop\Mun_Jin_Ho")){
            
            $fh = fopen("SMSFile.txt", 'a') or die("can't open file");
fwrite($fh, "New Stuff 1\n");
fwrite($fh, "New Stuff 2\n");
fclose($fh);
 
//파일 5글자 읽기
$fh = fopen("SMSFile.txt", 'r');
echo fread($fh, 5);
fclose($fh);
 
//한 라인 읽기
$fh = fopen("SMSFile.txt", 'r');
echo fgets($fh);
fclose($fh);
 
// 40번째 바이트로 간다음 240바이트를 읽어서 출력하기
$fh = fopen("SMSFile.txt", 'r');
fseek($file,40);
echo fread($file,240);
           }
           else{
             //일반적인 파일 읽기 사용 예
             $file_handle = fopen("SMSFile.txt", "r");
             while (!feof($file_handle)) {
             $line_of_text = fgets($file_handle);
             print $line_of_text . "<br>";
             }
 
            fclose($file_handle);
           }
        ?>
    </body>
</html>
