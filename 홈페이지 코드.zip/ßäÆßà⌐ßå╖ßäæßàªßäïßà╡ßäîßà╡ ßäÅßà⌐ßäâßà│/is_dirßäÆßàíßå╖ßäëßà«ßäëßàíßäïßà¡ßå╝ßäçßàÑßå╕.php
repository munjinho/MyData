<?php
    $dir = "main.PNG";

    if(is_dir($dir)// rmdir(안에 디렉터리 이름넣어도 상관없어요
      echo "$dir 디렉터리가 삭제되었습니다.";
    else{
        echo"디렉터리 삭제하는데 실패 하였습니다.";
    }
?>