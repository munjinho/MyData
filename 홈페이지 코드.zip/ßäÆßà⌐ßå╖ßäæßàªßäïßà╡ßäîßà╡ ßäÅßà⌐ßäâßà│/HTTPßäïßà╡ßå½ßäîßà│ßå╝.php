

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <?php
        $num=0;
        $timer=setcookie("test",$num+1,time()+5);//변수,값,만료시간
// 2초 동안 1출력 2초 이후 화이트 화면
      if(!$_SERVER['PHP_AUTH_USER']){
          header('www-Authenticate: basic realm="사용자 인증 시스템"');
          header('HTTP/1.0 401 Unauthorized');

          echo'사용자 인증에 실패하였습니다.';
          exit;
      }
      else{
          echo"<p>사용자 이름: {$_SERVER['PHP_AUTH_USER']}</P>";
          echo"<p>비밀번호 : {$_SERVER['PHP_AUTH_PW']}</p>";
      }

        
        ?>
    </body>
</html>
