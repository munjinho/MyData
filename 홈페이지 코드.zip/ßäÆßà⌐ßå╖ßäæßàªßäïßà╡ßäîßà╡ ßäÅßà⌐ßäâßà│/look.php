
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <?php
        $user="mjh9083";
        $pw="answlsgh93";
        
        if($_SERVER['PHP_AUTH_USER']==$user&&$_SERVER['PHP_AUTH_PW']==$pw){
            echo "로그인";
        }
        else{
            header('www-authenticate: basic realm="사용자 인증 시스템"');
            header('http/1.0 401unauthorized');
            echo'사용자 인증에 실패하였습니다.';
            exit;
        }    
        ?>
    </body>
</html>
