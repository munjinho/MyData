<?php
    for($a =1;$a<=10;$a++){
        echo("{$a}<br>");
    }
?>

