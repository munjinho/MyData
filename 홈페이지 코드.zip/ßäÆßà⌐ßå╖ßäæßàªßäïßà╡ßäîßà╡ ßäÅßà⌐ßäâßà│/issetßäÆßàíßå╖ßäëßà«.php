

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <?php
            $test1=0;
            $test2=1;
            //============
            $test3=TRUE;
            $test4=FALSE;
            setcookie('name',time());
            if(isset($_COOKIE['name']))
            // !을 사용했을경우 else수로 간다. 이유는 FALSE니까.
              echo"성공";
            else{
                //!를 사용하지않았을 경우 if로 간다 이유는 TRUE니까.
                echo"실패";
            }
            ?>
    </body>
</html>
