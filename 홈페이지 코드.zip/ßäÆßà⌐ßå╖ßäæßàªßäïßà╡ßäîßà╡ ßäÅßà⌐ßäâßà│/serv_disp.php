<?php
 print getenv("SEVER_SOFTWARE");
?>
