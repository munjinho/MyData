<?php
//print "오늘은".date("Y").date("m").date("j");
echo date("Y-m-d A:g:i:s");
?>

