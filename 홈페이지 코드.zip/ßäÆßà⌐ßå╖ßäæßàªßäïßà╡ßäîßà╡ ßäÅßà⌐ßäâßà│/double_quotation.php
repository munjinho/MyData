<?php
$a=123;
print "$a";
//print '$a'; 하면 변수가 -> 문자열로 변환
?>
