<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <?php
            echo $_COOKIE['php'];
            // 쿠키이름을 호출하면,쿠키 값을 불러온다.
            echo time()-$_COOKIE['php2'];
            // 쿠키이름을 호출하면,쿠키 값과, 만료시간을 불러온다.
            
        ?>

    </body>
</html>
