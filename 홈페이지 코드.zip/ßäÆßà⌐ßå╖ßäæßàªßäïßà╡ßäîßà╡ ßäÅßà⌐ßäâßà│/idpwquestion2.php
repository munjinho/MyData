<?php
        error_reporting(E_ALL);
        ini_set('display_errors', 'On');
        //echo "123";
         $hostname = "localhost";
         $mysql_id = "mjh9083";
         $mysql_pw = "answlsgh93";
         $mysql_database = "mjh9083";
    
         $id=20123008;//$_POST['id'];
         $answer='서울';//$_POST['answer'];
         $question=1;//$_POST['question'];   
         //$pw= 9083;
         $db = mysql_connect($hostname,$mysql_id,$mysql_pw,$mysql_database);// DB접속
         $con = mysql_select_db($mysql_database, $db);// DB선택 

         $query = mysql_query("SELECT * FROM Sign_up");
         if(mysql_num_rows($query) > 0){
             echo "success";
         }
         var_dump($db);
         var_dump($con);
?>

