<?php
    
         //     MYSQL 접속 //
    header("Content-Type: text/html; charset=UTF-8");
        $hostname = "localhost";
        $mysql_id = "mjh9083";
        $mysql_pw = "answlsgh93";
        $mysql_database = "mjh9083";
    //////////////////////////////////////
        //$id=$_POST['id'];
        //$pw=$_POST['pw'];
        //$name=$_POST['name'];
        //$sex=$_POST['sex'];
        //$phone=$_POST['phone'];
        //$birth=$_POST['birth'];
        //$question=$_POST['question'];
        //$answer=$_POST['answer'];
        $id=20123008;
        $pw=9083;
        $name="문진호";
        $sex="남자";
        $phone=01031999082;
        $birth=19930809;
        $question=0;
        $answer="서울";
        /////////////////////////////////////////////////////////
        $true=TRUE;
        $false=FALSE;


        $db = mysql_connect($hostname,$mysql_id,$mysql_pw,$mysql_database);
    
        echo "연결성공"; 
    
        mysql_select_db($mysql_database, $db);// DB선택
        mysql_query("set names utf8"); 
       
        $signin="insert into Sign_up(id,pw,name,sex,phone,birth,question) values ('$id','$pw','$name','$sex','$phone','$birth','$question')";// DB순서대로 데이터저장

        $signin=mysql_query($signin);//  회원가입할때 사용하는 쿼리문(SQL문)
        
    
         //////////////////////////////////////////////////////////////
    if($signin['id']){
        
    }
    
         
        if(!$id){
            echo "[접속 성공]";
        }
        else{
         die("[접속 종료]");
        }
        mysql_close($db)
        
?>
